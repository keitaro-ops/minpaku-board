import { NextResponse } from "next/server";
import { db } from "../../../lib/db.mjs";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

const DAY = 86400000;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const nights = (a, b) => {
  const n = Math.round((new Date(b) - new Date(a)) / DAY);
  return Number.isFinite(n) && n > 0 ? n : 1;
};
const key = (n, ci, co) => `${n}|${ci}|${co}`;

export async function GET() {
  try {
    const sql = db();
    const [resv, ov, ci, cl, sp, rd, mm, gc, cf, gman] = await Promise.all([
      sql`select property_name, area, platform, type,
                 to_char(check_in,'YYYY-MM-DD') as check_in,
                 to_char(check_out,'YYYY-MM-DD') as check_out,
                 res_code, res_url from reservations`,
      sql`select property_name, to_char(check_in,'YYYY-MM-DD') as check_in, to_char(check_out,'YYYY-MM-DD') as check_out, type from overrides`,
      sql`select property_name, to_char(check_in,'YYYY-MM-DD') as check_in, to_char(check_out,'YYYY-MM-DD') as check_out, submitted from checkin_status`,
      sql`select property_name, to_char(check_in,'YYYY-MM-DD') as check_in, to_char(check_out,'YYYY-MM-DD') as check_out, status, memo from cleaning_status`,
      sql`select property_name, to_char(check_in,'YYYY-MM-DD') as check_in, to_char(check_out,'YYYY-MM-DD') as check_out, boundaries from splits`,
      sql`select property_name, to_char(check_in,'YYYY-MM-DD') as check_in, to_char(check_out,'YYYY-MM-DD') as check_out, ready from ready_status`,
      sql`select property_name, to_char(check_in,'YYYY-MM-DD') as check_in, to_char(check_out,'YYYY-MM-DD') as check_out, memo from memo_status`,
      sql`select res_code, adults, children, guest_name from guest_counts`,
      sql`select res_code from change_flags where acknowledged = false`,
      sql`select property_name, to_char(check_in,'YYYY-MM-DD') as check_in, to_char(check_out,'YYYY-MM-DD') as check_out, adults, children from guest_manual`,
    ]);

    const gcM = new Map(gc.map((x) => [x.res_code, x]));
    const cfSet = new Set(cf.map((x) => x.res_code));
    const gmM = new Map(gman.map((x) => [key(x.property_name, x.check_in, x.check_out), x]));

    const ovM = new Map(ov.map((x) => [key(x.property_name, x.check_in, x.check_out), x.type]));
    const ciM = new Map(ci.map((x) => [key(x.property_name, x.check_in, x.check_out), x.submitted]));
    const clM = new Map(cl.map((x) => [key(x.property_name, x.check_in, x.check_out), x]));
    const spM = new Map(sp.map((x) => [key(x.property_name, x.check_in, x.check_out), x.boundaries]));
    const rdM = new Map(rd.map((x) => [key(x.property_name, x.check_in, x.check_out), x.ready]));
    const mmM = new Map(mm.map((x) => [key(x.property_name, x.check_in, x.check_out), x.memo]));

    const out = [];
    for (const r of resv) {
      const type = ovM.get(key(r.property_name, r.check_in, r.check_out)) ?? r.type;
      // 分割の境界を厳格に検証（不正なら分割しない＝壊れない）
      let segments = [[r.check_in, r.check_out, false]];
      const bnd = spM.get(key(r.property_name, r.check_in, r.check_out));
      if (bnd) {
        const cuts = [...new Set(String(bnd).split(",").map((s) => s.trim()))]
          .filter((d) => DATE_RE.test(d) && d > r.check_in && d < r.check_out)
          .sort();
        if (cuts.length > 0) {
          const pts = [r.check_in, ...cuts, r.check_out];
          segments = [];
          for (let i = 0; i < pts.length - 1; i++) segments.push([pts[i], pts[i + 1], true]);
        }
      }
      for (const [sci, sco, isSeg] of segments) {
        const k = key(r.property_name, sci, sco);
        const cln = clM.get(k);
        const g = !isSeg && r.res_code ? gcM.get(r.res_code) : null;
        const gmv = gmM.get(k); // 手動人数（物件+IN+OUT）: あれば優先
        const adults = gmv ? gmv.adults : (g ? g.adults : null);
        const children = gmv ? gmv.children : (g ? g.children : null);
        out.push({
          property_name: r.property_name, area: r.area, platform: r.platform,
          type: isSeg ? "booking" : type,
          check_in: sci, check_out: sco, nights: nights(sci, sco),
          res_code: isSeg ? null : r.res_code, res_url: r.res_url,
          info_submitted: ciM.get(k) ?? false,
          ready: rdM.get(k) ?? false,
          memo: mmM.get(k) ?? "",
          adults: adults,
          children: children,
          guest_name: g ? g.guest_name : "",
          changed: !isSeg && r.res_code ? cfSet.has(r.res_code) : false,
          cleaning_status: cln ? cln.status : "unrequested",
          cleaning_memo: cln ? cln.memo : "",
          split_ci: isSeg ? r.check_in : null,
          split_co: isSeg ? r.check_out : null,
        });
      }
    }
    out.sort((a, b) => a.property_name.localeCompare(b.property_name) || a.check_in.localeCompare(b.check_in));
    return NextResponse.json({ reservations: out });
  } catch (e) {
    return NextResponse.json({ error: String(e.message || e), reservations: [] }, { status: 500 });
  }
}
